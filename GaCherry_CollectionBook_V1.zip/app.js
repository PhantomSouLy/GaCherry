let cards=[];
fetch('cards.json').then(r=>r.json()).then(data=>{
 cards=data; render(cards);
});
function render(list){
 const g=document.getElementById('gallery');
 g.innerHTML='';
 list.forEach(c=>{
  const d=document.createElement('div');
  d.className='gcard';
  d.innerHTML=`<h3>${c.name}</h3><p>${c.rarity}</p>`;
  d.onclick=()=>openCard(c);
  g.appendChild(d);
 });
}
document.getElementById('search').addEventListener('input',e=>{
 const q=e.target.value.toLowerCase();
 render(cards.filter(c=>c.name.toLowerCase().includes(q)));
});
function openCard(c){
 document.getElementById('cardTitle').textContent=c.name;
 document.getElementById('cardRarity').textContent=c.rarity;
 document.getElementById('modal').style.display='block';
}
document.getElementById('close').onclick=()=>document.getElementById('modal').style.display='none';